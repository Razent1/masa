package telran.computer.computercontroller;

public class StringAppl {

	public static void main(String[] args) {
		String str1 = "Hello";
		String str2 = new String ("Hello");
		boolean check = str1.equals(str2); //сравнение строк через иквелс всегда выдаст верный результат 
		System.out.println(check);

	}

}
