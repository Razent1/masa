package telran.computer.computercontroller;

import telran.computer.model.Computer;
import telran.computer.model.Smartphone;

public class CompareAppl {

	public static void main(String[] args) {
		Computer comp1 = new Computer("i5", "Dell", 8, 512);
		Computer comp2 = new Computer("i5", "Dell", 8, 512);
		boolean check = comp1.equals(comp2); // метод сравнения 
		System.out.println(check);
	}

}
