package telran.computer.computercontroller;

import telran.computer.dao2.*;
import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class StockAppl {

	public static void main(String[] args) {
	Stock stock = new Stock(100);
	stock.addComputer(new Computer("i5", "Dell", 8, 512));
	stock.addComputer(new Laptop("i7", "Asus", 16, 512, 2.5, 1.5));
	stock.addComputer(new Smartphone("Snapdragon", "Honor", 8, 64, 48, 0.2, 30916863515931l));
	stock.addComputer(new Laptop("i5", "Dell", 8, 512, 2.4, 3));
	stock.addComputer(new Computer("i5", "Dell", 8, 512));
	stock.addComputer(new Laptop("i7", "Asus", 16, 512, 2.5, 1.5));
	stock.addComputer(new Smartphone("Snapdragon", "Honor", 8, 64, 48, 0.2, 30916863515931l));
	stock.addComputer(new Laptop("i5", "Dell", 8, 512, 2.4, 3));
	//Computer comp2 = new Computer("i5", "Dell", 8, 512);
	Laptop lpt2 = new Laptop("i5", "Dell", 8, 512, 2.4, 3);
	//Smartphone smart2 = new Smartphone("Snapdragon", "Honor", 8, 64, 48, 0.2, 30916863515931l);
	stock.addComputer(lpt2);
	//stock.addComputer(smart2);
	//stock.addComputer(comp2);
	stock.remove(lpt2);
	
	//stock.remove2(0);

	System.out.println("Desktops : " + stock.calcDesktops());
	System.out.println("Smartphones : " + stock.calcSmartphones());
	System.out.println("Laptops : " + stock.calcLaptops());
	}

}
