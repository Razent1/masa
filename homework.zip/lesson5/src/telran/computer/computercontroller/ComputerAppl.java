package telran.computer.computercontroller;

import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class ComputerAppl {

	public static void main(String[] args) {
	Computer comp1 = new Computer("i5", "Dell", 8, 512);
	Computer lap1 = new Laptop("i7", "Asus", 16, 512, 2.5, 1.5);
	Computer smart1 = new Smartphone("Snapdragon", "Honor", 8, 64, 48, 0.2, 30916863515931l); // ссылка родителя может служить и ссылкой его предка 
	System.out.println(smart1);
	int totalSize = comp1.getHdd() + smart1.getHdd();
	System.out.println(totalSize);

	}

}
