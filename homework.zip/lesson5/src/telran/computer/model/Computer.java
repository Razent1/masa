package telran.computer.model;

public class Computer {
	private String cpu;
	private String brand;
	private int ram;
	private int hdd;
	
	
	public Computer() {
	}


	public Computer(String cpu, String brand, int ram, int hdd) {
		this.cpu = cpu;
		this.brand = brand;
		this.ram = ram;
		this.hdd = hdd;
	}


	public String getCpu() {
		return cpu;
	}


	public void setCpu(String cpu) {
		this.cpu = cpu;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public int getRam() {
		return ram;
	}


	public void setRam(int ram) {
		this.ram = ram;
	}


	public int getHdd() {
		return hdd;
	}


	public void setHdd(int hdd) {
		this.hdd = hdd;
	}


	@Override
	public String toString() {
		return "cpu=" + cpu + ", brand=" + brand + ", ram=" + ram + ", hdd=" + hdd;
	}
	public boolean equals(Object other) {
		if(other instanceof Computer) {
			Computer comp = (Computer) other;
			return cpu.equals(comp.cpu) 
					&& brand.equals(comp.brand)
					&& ram == comp.ram && hdd == comp.hdd;
		}else {
			return false;
		}
	
	}
}
