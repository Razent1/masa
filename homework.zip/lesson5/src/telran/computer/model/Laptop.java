package telran.computer.model;

public class Laptop extends Computer {
	private double hours;
	private double weight;
	public Laptop() {
		super();
	}
	public Laptop(String cpu, String brand, int ram, int hdd, double hours, double weight) {
		super(cpu, brand, ram, hdd);
		this.hours = hours;
		this.weight = weight;

	}
	public double getHours() {
		return hours;
	}
	public void setHours(double hours) {
		this.hours = hours;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return super.toString() + " hours=" + hours + ", weight=" + weight;
	}
	
	public boolean equals(Object other)
	{
		if(other instanceof Laptop)
		{
			Laptop lap = (Laptop) other; //кастинг
			return super.equals(lap) && weight == lap.weight && hours == lap.hours;
		}
		else
		{
			return false;
		}
	}
}
