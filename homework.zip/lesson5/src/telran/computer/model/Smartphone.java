package telran.computer.model;

public class Smartphone extends Laptop {
	private long imei;

	public Smartphone(String cpu, String brand, int ram, int hdd, double hours, double weight, long imei) {
		super(cpu, brand, ram, hdd, hours, weight);
		this.imei = imei;
	}

	public long getImei() {
		return imei;
	}

	public void setImei(long imei) {
		this.imei = imei;
	}

	@Override
	public String toString() {
		return super.toString() + "imei=" + imei;
	}
	public boolean equals(Object other)
	{
		if(other instanceof Smartphone)
		{
			Smartphone smart = (Smartphone) other;
			return imei == smart.imei;
		}
		else
		{
			return false;
		}
	}
	
}
