package telran.computer.dao2;

import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class Stock {
	private Computer computers[];
	private int size;
	
	public Stock(int capacity)
	{
		this.computers = new Computer[capacity];
		size = 0;
	}

	public Computer[] getComputers() {
		return computers;
	}

	public int getSize() {
		return size;
	}
	public boolean addComputer(Computer computer)
	{
		if(size == computers.length)
		{
			return false;
		}
		computers[size] = computer;
		size++;
		return true;
	}
	
	public void printStock()
	{
		for (int i = 0; i < size; i++) {
			System.out.println(computers[i]);
		}
	}
	public int calcDesktops()
	{
		int j;
		
		j = 0;	
		for(int i = 0; i < size; i++)
		{
			if((computers[i] instanceof Laptop == false) && (computers[i] instanceof Smartphone == false) && (computers[i]  != null))
			j++;
		}
		return j;
	}
	public int calcSmartphones()
	{
		int j;
		
		j = 0;
		for(int i = 0; i < size; i++)
		{
			if((computers[i] instanceof Smartphone) && (computers[i]  != null))
			j++;
		}
		return j;
	}
	public int calcLaptops()
	{
		int j;
		
		j = 0;
		for(int i = 0; i < size; i++)
		{
			if((computers[i] instanceof Laptop) && (computers[i] instanceof Smartphone == false) && (computers[i]  != null))
				j++;
		}
		return j;
	}
	public void remove(Computer computer)
	{
		for(int i = 0; i < size; i++)
		{
			if(computers[i] == computer)
			{
				Computer tmp = computers[i];
				computers[i] = null;
				computers[i + 1] = tmp;
			}
		}
	}
	public void remove2(int n)
	{
		for(int i = 0; i < computers.length; i++)
		{
			if(computers[i] == computers[n])
			{
				computers[i] = null;
			}
		}
	}
}
//дз метод - remove(Computer computer)// int Calc Smatphones(), int calc Laptops, int Calc Desktops
